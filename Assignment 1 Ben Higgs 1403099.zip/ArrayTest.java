/**
 * Created by Ben on 07-Feb-15.
 */
public class ArrayTest {

    public void main (String[] args){
        MyArrayList x = new MyArrayList();
        System.out.println("array list x created");
        MyArrayList.add(1);

    }
}
